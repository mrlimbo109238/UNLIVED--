## UNLIVED — game menus: frame, navigation, settings, saves, history,
## endings, about, controls, confirmation, accessibility.
init offset = 12

style u_nav_text is default:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 34
    color "#a79790"
    hover_color "#f6ece2"
    selected_color "#f2c4a5"
    selected_hover_color "#ffe1cc"

style u_brand is default:
    font "fonts/CormorantGaramond-Light.ttf"
    size 60
    kerning 10
    color "#f1e6da"

style u_page is u_button:
    padding (12, 8)
    activate_sound "audio/ui/ux_toggle.ogg"

style u_page_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 17
    kerning 2
    color "#8d7c76"
    hover_color "#efe3d6"
    selected_color "#f2c4a5"

style u_slot is u_button

style u_slot_title is default:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 28
    color "#efe3d6"

style u_slot_meta is default:
    font "fonts/Manrope-Medium.ttf"
    size 16
    kerning 1
    color "#9a8882"

style u_slot_num is default:
    font "fonts/Manrope-SemiBold.ttf"
    size 14
    kerning 3
    color "#f1e6da"
    outlines [(absolute(3), "#0b0810aa", absolute(0), absolute(0))]

style u_card_num is default:
    font "fonts/CormorantGaramond-Light.ttf"
    size 132
    color "#f6d7c0"

style u_card_num_locked is u_card_num:
    color "#4d4044"

style u_card_title is default:
    font "fonts/CormorantGaramond-Italic.ttf"
    size 31
    color "#f1e6da"
    line_spacing 2

style u_card_locked is default:
    font "fonts/Manrope-Medium.ttf"
    size 18
    kerning 1
    color "#6f6061"

style u_hist_name is default:
    font "fonts/CormorantGaramond-SemiBold.ttf"
    size 28
    color "#cdbab0"
    min_width 260
    xmaximum 260
    text_align 1.0

style u_hist_text is default:
    font "fonts/Lora-Regular.ttf"
    size 24
    color "#e6dad0"
    line_spacing 8
    xsize 880

style u_preview_text is default:
    font "fonts/Lora-Regular.ttf"
    size 26
    color "#efe3d6"
    line_spacing 8
    xsize 700
    textshader "dissolve"

style u_modal_text is default:
    font "fonts/CormorantGaramond-Regular.ttf"
    size 42
    color "#f3e8dc"
    text_align 0.5
    line_spacing 2

## ---------------------------------------------------------------- frame

screen u_nav_item(caption, action):
    button:
        style "u_button"
        action action
        xsize 360
        ysize 52
        fixed:
            add "images/ui/diamond.png" xpos 0 yalign 0.5 zoom 0.75 at u_show_on_selected
            text caption style "u_nav_text" xpos 30 yalign 0.5 at u_shift(10)

screen navigation():
    vbox:
        pos (98, 88)
        spacing 0
        text "UNLIVED" style "u_brand"
        text "Грехи желаний" style "u_hand" size 32 xpos 4

    vbox:
        pos (86, 286)
        spacing 0
        if main_menu:
            use u_nav_item("Новая игра", Start("unlived_new_game"))
        else:
            use u_nav_item("Продолжить", Return())
            use u_nav_item("История", ShowMenu("history"))
            use u_nav_item("Сохранить", ShowMenu("save"))
        use u_nav_item("Загрузить", ShowMenu("load"))
        use u_nav_item("Настройки", ShowMenu("preferences"))
        use u_nav_item("Концовки", ShowMenu("endings_gallery"))
        use u_nav_item("Управление", ShowMenu("help"))
        use u_nav_item("Об игре", ShowMenu("about"))
        null height 22
        if main_menu:
            use u_nav_item("Главное меню", Return())
        else:
            use u_nav_item("Главное меню", MainMenu())
        use u_nav_item("Выйти", Quit(confirm=True))

    button:
        style "u_button"
        activate_sound "audio/ui/ux_back.ogg"
        action Return()
        pos (98, 994)
        hbox:
            spacing 16
            use u_key("Esc")
            text "НАЗАД" style "u_link_text" yalign 0.5

screen game_menu(title, scroll=None, yinitial=0.0, spacing=0, eyebrow=None):
    add "unlived_menu_bg" at unlived_bg_cam
    add "images/ui/gm_shade.png"
    add "unlived_grain_fx"
    add "images/ui/line_v.png" xpos 476

    use navigation

    fixed:
        pos (580, 0)
        xysize (1270, 1080)

        vbox:
            ypos 90
            spacing 2
            at u_rise(0.0, 0.5, 12)
            text ((eyebrow or "UNLIVED").upper()) style "u_eyebrow"
            text title style "u_title"

        add "images/ui/rule.png" ypos 248 xsize 640 at u_grow(0.08, 0.8)

        fixed:
            ypos 296
            xysize (1270, 700)
            at u_rise(0.06, 0.5, 14)

            if scroll == "viewport":
                viewport:
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True
                    side_spacing 24
                    vbox:
                        spacing spacing
                        transclude
            else:
                transclude

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")

## ---------------------------------------------------------------- settings

screen preferences(tab="main"):
    tag menu
    default cur = tab
    use game_menu("Настройки", eyebrow="Параметры"):
        vbox:
            spacing 0
            use u_tabs([("main", "Основное"), ("sound", "Звук"), ("gfx", "Графика"), ("access", "Доступность")], cur, "cur")
            null height 40
            if cur == "main":
                use u_prefs_main
            elif cur == "sound":
                use u_prefs_sound
            elif cur == "gfx":
                use u_prefs_gfx
            else:
                use u_prefs_access

screen u_prefs_main():
    vbox:
        spacing 26
        at u_rise(0.0, 0.35, 10)
        use u_row("Режим экрана", "F — переключить в игре"):
            use u_seg([("В окне", Preference("display", "any window")), ("Полный экран", Preference("display", "fullscreen"))])
        use u_row("Пропуск текста", "Ctrl — удерживать, Tab — переключить"):
            use u_seg([("Только прочитанное", Preference("skip", "seen")), ("Весь текст", Preference("skip", "all"))])
        use u_row("После выбора"):
            use u_seg([("Останавливать пропуск", Preference("after choices", "stop")), ("Продолжать", Preference("after choices", "skip"))])
        null height 2
        use u_slider("Скорость текста", Preference("text speed"), unlived_cps_text())
        use u_slider("Авточтение", Preference("auto-forward time"), unlived_afm_text(), note="Пауза перед следующей репликой")
        hbox:
            spacing 40
            null width 420
            vbox:
                spacing 12
                text "ПРИМЕР ТЕКСТА" style "u_eyebrow_dim"
                if preferences.text_cps:
                    text "Вечерний свет медленно таял на стене, и комната снова казалась чужой." style "u_preview_text" slow_cps preferences.text_cps
                else:
                    text "Вечерний свет медленно таял на стене, и комната снова казалась чужой." style "u_preview_text"

screen u_prefs_sound():
    vbox:
        spacing 30
        at u_rise(0.0, 0.35, 10)
        if config.has_music:
            use u_slider("Музыка", Preference("music volume"), unlived_pct("music"))
        if config.has_sound:
            use u_slider("Звуки", Preference("sound volume"), unlived_pct("sfx"), note="Интерфейс и эффекты")
        if config.has_voice:
            use u_slider("Голос", Preference("voice volume"), unlived_pct("voice"))
        use u_toggle("Без звука", Preference("all mute", "toggle"), note="Временно отключить весь звук")
        use u_row("Проверка звука"):
            textbutton "ПРОИГРАТЬ" action Play("sound", "audio/ui/ux_select.ogg") style "u_btn"

screen u_prefs_gfx():
    vbox:
        spacing 24
        at u_rise(0.0, 0.35, 10)
        use u_toggle("Параллакс в главном меню", ToggleField(persistent, "unlived_parallax"), note="Комната откликается на движение мыши")
        use u_toggle("Атмосферные эффекты", ToggleField(persistent, "unlived_fx"), note="Свет из окна, пыль и плёночное зерно")
        use u_row("Частота кадров", "Целевая, итог зависит от видеокарты"):
            use u_seg([("По частоте экрана", Preference("gl framerate", None)), ("60 кадров/с", Preference("gl framerate", 60))])
        use u_row("Режим работы"):
            use u_seg([("Плавность", Preference("gl powersave", False)), ("Экономия энергии", Preference("gl powersave", True))])
        use u_row("Графический движок", "Сейчас: " + unlived_renderer_name() + ". После перезапуска"):
            use u_seg([("Авто", _SetRenderer("auto")), ("OpenGL", _SetRenderer("gl2"))] + ([("DirectX", _SetRenderer("angle2"))] if renpy.windows else []))
        use u_toggle("Счётчик кадров", ToggleScreen("_performance"))

screen u_prefs_access():
    vbox:
        spacing 26
        at u_rise(0.0, 0.35, 10)
        use u_slider("Размер текста", Preference("font size"), "× %.2f" % preferences.font_size)
        use u_slider("Межстрочный интервал", Preference("font line spacing"), "× %.2f" % preferences.font_line_spacing)
        use u_row("Шрифт"):
            use u_seg([("Авторский", Preference("font transform", None)), ("DejaVu Sans", Preference("font transform", "dejavusans")), ("OpenDyslexic", Preference("font transform", "opendyslexic"))])
        use u_toggle("Высокий контраст текста", Preference("high contrast text", "toggle"))
        use u_row("Озвучивание интерфейса", "Shift + A — полное меню доступности"):
            use u_seg([("Выкл.", Preference("self voicing", "disable")), ("Синтез речи", Preference("self voicing", "enable")), ("Буфер обмена", Preference("clipboard voicing", "enable"))])
        hbox:
            spacing 40
            null width 420
            textbutton "СБРОСИТЬ ТЕКСТОВЫЕ НАСТРОЙКИ" action [Preference("font size", 1.0), Preference("font line spacing", 1.0), Preference("font transform", None), Preference("high contrast text", "disable")] style "u_link"

## ---------------------------------------------------------------- saves

screen save():
    tag menu
    use file_slots("Сохранить", "save")

screen load():
    tag menu
    use file_slots("Загрузить", "load")

screen u_slot(slot, mode):
    $ loadable = FileLoadable(slot)
    button:
        style "u_slot"
        xysize (384, 290)
        action FileAction(slot)
        alt ("Слот %d" % slot)
        at u_lift
        key "save_delete" action FileDelete(slot)
        fixed:
            fixed:
                xysize (384, 216)
                add Solid("#120d16")
                if loadable:
                    add FileScreenshot(slot)
                else:
                    vbox:
                        align (0.5, 0.5)
                        spacing 12
                        add "images/ui/diamond_o.png" xalign 0.5 alpha 0.6
                        text ("СОХРАНИТЬ СЮДА" if mode == "save" else "ПУСТОЙ СЛОТ") style "u_eyebrow_dim" xalign 0.5
                add Frame("images/ui/fr_line.png", 8, 8)
                add Frame("images/ui/fr_line_h.png", 8, 8) at u_show_on_hover
                text ("%02d" % slot) style "u_slot_num" pos (16, 12)
            if loadable:
                text unlived_slot_chapter(slot).replace(" / ", " · ") style "u_slot_title" ypos 226 xsize 384
                text FileTime(slot, format="%d.%m.%Y   ·   %H:%M") style "u_slot_meta" ypos 264

screen file_slots(title, mode="load"):
    python:
        cp = FileCurrentPage()
        if cp == "auto":
            page_label = "Автосохранения"
        elif cp == "quick":
            page_label = "Быстрые сохранения"
        else:
            page_label = "Страница %s" % cp

    use game_menu(title, eyebrow=("Запись прогресса" if mode == "save" else "Вернуться в историю")):
        fixed:
            xysize (1260, 700)
            hbox:
                ypos 4
                use u_section(page_label)
            hbox:
                xalign 1.0
                ypos -8
                spacing 2
                textbutton "‹" action FilePagePrevious() style "u_page" text_size 24
                textbutton "АВТО" action FilePage("auto") style "u_page"
                textbutton "БЫСТР." action FilePage("quick") style "u_page"
                for p in range(1, 10):
                    textbutton str(p) action FilePage(p) style "u_page"
                textbutton "›" action FilePageNext() style "u_page" text_size 24
            grid 3 2:
                ypos 62
                xspacing 54
                yspacing 26
                for i in range(6):
                    use u_slot(i + 1, mode)
            text "Delete — удалить выбранное сохранение" style "u_note" size 18 ypos 676

## ---------------------------------------------------------------- history

screen history():
    tag menu
    predict False
    use game_menu("История", scroll="viewport", yinitial=1.0, spacing=30, eyebrow="Прочитанное"):
        for h in _history_list:
            hbox:
                spacing 40
                if h.who:
                    text h.who style "u_hist_name" substitute False:
                        if "color" in h.who_args:
                            color h.who_args["color"]
                else:
                    null width 260
                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                if h.who and h.who.endswith("мысли"):
                    text what style "u_hist_text" substitute False italic True color "#cbbfb6"
                else:
                    text what style "u_hist_text" substitute False
        if not _history_list:
            text "Здесь появятся прочитанные реплики." style "u_note"

## ---------------------------------------------------------------- endings

screen u_ending_card(n):
    $ is_open = n in persistent.unlived_endings
    fixed:
        xysize (294, 520)
        at u_rise(0.05 + 0.07 * n, 0.6, 24)
        add Frame(("images/ui/card_open.png" if is_open else "images/ui/card_locked.png"), 10, 10)
        text "КОНЦОВКА" style ("u_eyebrow" if is_open else "u_eyebrow_dim") xalign 0.5 ypos 46
        text unlived_roman[n] style ("u_card_num" if is_open else "u_card_num_locked") xalign 0.5 ypos 76
        add "images/ui/diamond.png" xalign 0.5 ypos 264 zoom 0.7 alpha (1.0 if is_open else 0.25)
        if is_open:
            text ending_titles[n] style "u_card_title" xalign 0.5 ypos 304 xsize 236 text_align 0.5
        else:
            text "Ещё не открыта" style "u_card_locked" xalign 0.5 ypos 306 text_align 0.5
        text unlived_ending_paths[n].upper() style "u_eyebrow_dim" size 14 xalign 0.5 ypos 464

screen endings_gallery():
    tag menu
    $ opened = len(persistent.unlived_endings)
    use game_menu("Концовки", eyebrow="Четыре исхода"):
        vbox:
            spacing 0
            hbox:
                spacing 26
                text ("Открыто %d из 4" % opened) style "u_label"
                hbox:
                    spacing 8
                    yalign 0.5
                    for n in range(1, 5):
                        add ("images/ui/pip_on.png" if n in persistent.unlived_endings else "images/ui/pip_off.png")
            null height 36
            hbox:
                spacing 28
                for n in range(1, 5):
                    use u_ending_card(n)
            null height 30
            text "Каждое решение Луки сдвигает историю к свету или во тьму. Пройдите её снова, чтобы открыть остальные финалы." style "u_note" xsize 1220

## ---------------------------------------------------------------- about

screen about():
    tag menu
    use game_menu("Об игре", scroll="viewport", eyebrow="UNLIVED · Грехи желаний"):
        hbox:
            spacing 90
            vbox:
                xsize 640
                spacing 16
                use u_section("История")
                text "Психологическая визуальная новелла с четырьмя концовками. Ваши решения меняют путь Луки и его отношения с Надей." style "u_body"
                null height 24
                use u_section("Внимание · 18+")
                text "В тексте присутствуют семейное и сексуальное насилие, травля, смерть близких, психические расстройства, самоповреждение и суицид. Некоторые сцены содержат грубую лексику и тяжёлые подробности. Игра не является рекомендацией по лечению." style "u_note"
                null height 24
                use u_section("Версия")
                text ("UNLIVED " + config.version) style "u_label"
            vbox:
                xsize 480
                spacing 16
                use u_section("Создание")
                text "Сценарий «Грехи желаний»\nОснова: remarkablegames/renpy-template (MIT)\nРесурсы шаблона: Uncle Mugen, Kenney, dmochas-assets" style "u_note"
                null height 24
                use u_section("Шрифты")
                text "Cormorant Garamond, Lora, Manrope, Marck Script — SIL Open Font License 1.1. Тексты лицензий: game/fonts/credits." style "u_note"
                null height 24
                use u_section("Движок")
                text ("Сделано на {a=https://www.renpy.org/}Ren’Py{/a} " + renpy.version_only + ".") style "u_note"
                text "Программа содержит свободное ПО под разными лицензиями, включая MIT и GNU LGPL. Полный список компонентов и ссылки на исходный код — {a=https://www.renpy.org/l/license}на сайте Ren’Py{/a}." style "u_note" size 17

## ---------------------------------------------------------------- controls

style u_help_text is u_text:
    font "fonts/Manrope-Regular.ttf"
    size 20
    color "#b9a89f"
    line_spacing 4

style u_help_dash is u_text:
    font "fonts/Manrope-Regular.ttf"
    size 20
    color "#7d6d67"

screen help():
    tag menu
    default device = "keyboard"
    python:
        if device == "mouse":
            rows = [(["ЛКМ"], "Следующая реплика, выбор"), (["ПКМ"], "Меню игры"), (["Колесо ↑"], "Назад по прочитанному"), (["Колесо ↓"], "Вперёд по прочитанному"), (["Средняя"], "Скрыть интерфейс")]
        elif device == "gamepad":
            rows = [(["A"], "Следующая реплика, выбор"), (["Крестовина"], "Навигация по меню"), (["B"], "Меню игры"), (["LT"], "Назад по прочитанному"), (["RT"], "Вперёд по прочитанному"), (["Y"], "Скрыть интерфейс")]
        else:
            rows = [(["Enter", "Пробел"], "Следующая реплика"), (["Esc"], "Меню игры, назад"), (["Ctrl"], "Пропуск, пока клавиша зажата"), (["Tab"], "Включить или выключить пропуск"), (["Page Up"], "Назад по прочитанному"), (["Page Down"], "Вперёд по прочитанному"), (["1", "…", "9"], "Выбор варианта ответа"), (["H"], "Скрыть интерфейс"), (["F"], "Полноэкранный режим"), (["S"], "Снимок экрана"), (["Shift", "A"], "Специальные возможности")]
    use game_menu("Управление", eyebrow="Клавиши и жесты"):
        vbox:
            spacing 0
            use u_tabs([("keyboard", "Клавиатура"), ("mouse", "Мышь")] + ([("gamepad", "Геймпад")] if GamepadExists() else []), device, "device")
            null height 52
            vpgrid:
                cols 3
                xspacing 56
                yspacing 40
                at u_rise(0.0, 0.35, 10)
                for keys, explanation in rows:
                    vbox:
                        xsize 380
                        spacing 14
                        hbox:
                            spacing 8
                            for k in keys:
                                if k == "…":
                                    text "—" style "u_help_dash" yalign 0.5
                                else:
                                    use u_key(k)
                        text explanation style "u_help_text"
                for i in range((3 - len(rows) % 3) % 3):
                    null
            if device == "gamepad":
                null height 40
                textbutton "КАЛИБРОВКА" action GamepadCalibrate() style "u_btn"

## ---------------------------------------------------------------- confirm

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    add Solid("#07050ad0") at u_dim_in
    frame:
        style "u_panel"
        xalign 0.5
        yalign 0.5
        xsize 1000
        at u_modal_in
        vbox:
            xfill True
            spacing 0
            add "images/ui/diamond_o.png" xalign 0.5
            null height 22
            text "ПОДТВЕРЖДЕНИЕ" style "u_eyebrow" xalign 0.5
            null height 26
            text _(message) style "u_modal_text" xalign 0.5 xmaximum 840
            null height 44
            hbox:
                xalign 0.5
                spacing 24
                textbutton "ДА" action yes_action style "u_btn"
                textbutton "НЕТ" action no_action style "u_btn" activate_sound "audio/ui/ux_back.ogg"
    key "game_menu" action no_action

## ---------------------------------------------------------------- input

screen input(prompt):
    style_prefix "input"
    frame:
        style "u_panel"
        xalign 0.5
        yalign 0.5
        xsize 1100
        vbox:
            spacing 28
            text prompt style "u_h3"
            input id "input" style "u_body" color "#f6d2b8"

## ---------------------------------------------------------------- accessibility (Shift+A)

screen _accessibility():
    layer config.interface_layer
    zorder 2000
    modal True
    default page = "text"
    add Solid("#07050ae0") at u_dim_in
    frame:
        style "u_panel"
        xalign 0.5
        yalign 0.5
        xsize 1460
        at u_modal_in
        vbox:
            spacing 0
            text "ДОСТУПНОСТЬ" style "u_eyebrow"
            text "Специальные возможности" style "u_title" size 64
            null height 26
            use u_tabs([("text", "Текст"), ("audio", "Звук и озвучивание")], page, "page")
            null height 36
            if page == "text":
                use u_prefs_access
            else:
                vbox:
                    spacing 26
                    use u_row("Озвучивание интерфейса"):
                        use u_seg([("Выкл.", Preference("self voicing", "disable")), ("Синтез речи", Preference("self voicing", "enable")), ("Буфер обмена", Preference("clipboard voicing", "enable"))])
                    use u_slider("Громкость голоса", Preference("voice volume"), unlived_pct("voice"))
                    use u_slider("Приглушение при озвучивании", Preference("self voicing volume drop"), "")
                    use u_toggle("Монофонический звук", Preference("mono audio", "toggle"))
            null height 40
            textbutton "ЗАКРЫТЬ" action Hide("_accessibility") style "u_btn"
    key "game_menu" action Hide("_accessibility")

## ---------------------------------------------------------------- FPS overlay

screen _performance():
    layer config.interface_layer
    zorder 1000
    on "show" action Function(_clear_performance)
    python:
        _ft = renpy.display.interface.frame_times
        _dt = [b - a for a, b in zip(_ft, _ft[1:])][-10:]
        _fps = (len(_dt) / sum(_dt)) if _dt and sum(_dt) > 0 else 0.0
        _ms = _dt[-1] * 1000 if _dt else 0.0
    drag:
        draggable True
        focus_mask None
        xpos 1560
        ypos 40
        frame:
            background Frame("images/ui/fr_pill.png", 18, 18)
            padding (26, 14)
            vbox:
                spacing 4
                text ("%.0f кадр/с" % _fps) style "u_value" size 22
                text ("кадр %.1f мс · %s" % (_ms, unlived_renderer_name())) style "u_note" size 16
