## UNLIVED — interface, early layer.
## Runs before characters.rpy so every Character inherits the new defaults.
init offset = -5

transform unlived_ctc_t:
    subpixel True
    xoffset 12
    yoffset -5
    alpha 0.0
    easein 0.4 alpha 1.0
    block:
        ease 0.95 alpha 0.3 yoffset -3
        ease 0.95 alpha 1.0 yoffset -5
        repeat

init python:
    # Real bold and italic faces instead of synthetic slanting (thoughts use italics).
    for _u_base, _u_bold, _u_italic in (
        ("fonts/Lora-Regular.ttf", "fonts/Lora-SemiBold.ttf", "fonts/Lora-Italic.ttf"),
        ("fonts/CormorantGaramond-Regular.ttf", "fonts/CormorantGaramond-SemiBold.ttf", "fonts/CormorantGaramond-Italic.ttf"),
        ("fonts/CormorantGaramond-Medium.ttf", "fonts/CormorantGaramond-SemiBold.ttf", "fonts/CormorantGaramond-MediumItalic.ttf"),
        ("fonts/CormorantGaramond-Light.ttf", "fonts/CormorantGaramond-Medium.ttf", "fonts/CormorantGaramond-Italic.ttf"),
    ):
        config.font_replacement_map[_u_base, True, False] = (_u_bold, False, False)
        config.font_replacement_map[_u_base, False, True] = (_u_italic, False, False)
        config.font_replacement_map[_u_base, True, True] = (_u_italic, False, False)
    config.font_replacement_map["fonts/Lora-Regular.ttf", True, True] = ("fonts/Lora-MediumItalic.ttf", False, False)
    config.font_replacement_map["fonts/Manrope-Regular.ttf", True, False] = ("fonts/Manrope-Bold.ttf", False, False)

    # Default speaker: a softly pulsing diamond marks "click to continue".
    adv = Character(None, kind=adv,
        ctc=At("images/ui/ctc.png", unlived_ctc_t),
        ctc_position="nestled")
