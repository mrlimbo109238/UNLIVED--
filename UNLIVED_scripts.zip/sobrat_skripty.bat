@echo off
setlocal
echo Sobirayu skripty UNLIVED, podozhdite...
set "ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r=$env:ROOT; $o=Join-Path $r 'UNLIVED_scripts'; $z=Join-Path $r 'UNLIVED_scripts.zip'; if(Test-Path $o){Remove-Item $o -Recurse -Force}; if(Test-Path $z){Remove-Item $z -Force}; $f=Get-ChildItem -LiteralPath $r -Recurse -File | Where-Object { $_.Extension -in '.rpy','.txt','.iss','.bat','.md','.json' -and $_.Length -lt 5MB -and $_.FullName -notmatch '\\(renpy|lib|cache|saves|UNLIVED_scripts)\\' }; foreach($i in $f){ $d=Join-Path $o $i.FullName.Substring($r.Length); New-Item -ItemType Directory -Force -Path (Split-Path $d) | Out-Null; Copy-Item -LiteralPath $i.FullName -Destination $d }; Compress-Archive -Path (Join-Path $o '*') -DestinationPath $z -Force; Remove-Item $o -Recurse -Force; Write-Host ''; Write-Host ('Gotovo! Faylov: ' + $f.Count + ', razmer arhiva: ' + [math]::Round((Get-Item $z).Length/1MB,2) + ' MB'); Write-Host 'Fayl UNLIVED_scripts.zip lezhit ryadom s etim skriptom.'; Invoke-Item $r"
echo.
pause
