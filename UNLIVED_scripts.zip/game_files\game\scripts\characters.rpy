# Named speakers. No synthetic voice bleeps during serious scenes.
define luka = Character("Лука", who_color="#b9d3bb")
define igor = Character("Игорь", who_color="#a5c8df")
define nina = Character("Нина", who_color="#dcc1bc")
define stas = Character("Стас", who_color="#d9ca9b")
define nadya = Character("Надя", who_color="#e0b69d")
define anna = Character("Анна", who_color="#d6d1b7")
define leader = Character("Главарь", who_color="#d3d8d8")
define bully = Character("Хулиган", who_color="#d3d8d8")
define bullies = Character("Хулиганы", who_color="#d3d8d8")
define senior = Character("Старшеклассник", who_color="#d3d8d8")
define inner_voice = Character("Голос", who_color="#c7a6a6")
define entity = Character("Сущность", who_color="#c7a6a6")
define friend = Character("Друг", who_color="#d3d8d8")
define friends = Character("Ребята из секции", who_color="#d3d8d8")
define egor = Character("Егор", who_color="#d3d8d8")
define alisa = Character("Алиса", who_color="#d3d8d8")
define little_stas = Character("Стасик", who_color="#d3d8d8")
define narrator = Character(None)
define thought_luka = Character("Лука / мысли", who_color="#b9c4cf", what_italic=True)
define thought_igor = Character("Игорь / мысли", who_color="#b9c4cf", what_italic=True)
define thought_stas = Character("Стас / мысли", who_color="#b9c4cf", what_italic=True)
define thought_nadya = Character("Надя / мысли", who_color="#b9c4cf", what_italic=True)

init python:
    def unlock_unlived_ending(number):
        if number not in persistent.unlived_endings:
            persistent.unlived_endings = persistent.unlived_endings + [number]
            renpy.save_persistent()
