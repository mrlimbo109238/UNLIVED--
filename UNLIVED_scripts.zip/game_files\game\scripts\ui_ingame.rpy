## UNLIVED — in-game interface: dialogue, quick menu, choices, chapter and ending cards.
init offset = 12

## ---------------------------------------------------------------- dialogue

style window:
    xfill True
    yalign 1.0
    ysize 560
    background "images/ui/grad_bottom.png"
    padding (0, 0)

style say_label:
    font "fonts/CormorantGaramond-SemiBold.ttf"
    size 38
    color "#f1e6da"
    xpos 340
    ypos 232
    outlines [(absolute(3), "#09070c66", absolute(0), absolute(1))]

style say_dialogue:
    font "fonts/Lora-Regular.ttf"
    size 30
    color "#f1e7dd"
    xpos 340
    ypos 290
    xsize 1260
    line_spacing 7
    textshader "dissolve"
    outlines [(absolute(2), "#09070c55", absolute(0), absolute(1))]

screen say(who, what):
    text unlived_chapter_caps(chapter_title) style "u_eyebrow_dim" pos (92, 60) at u_fade(0.0, 0.6)

    window:
        id "window"
        if who is not None:
            add "images/ui/diamond.png" pos (308, 250) zoom 0.6
            text who id "who"
        text what id "what"

style u_qm is u_button:
    padding (6, 6)
    hover_sound "audio/ui/ux_hover.ogg"
    activate_sound "audio/ui/ux_toggle.ogg"

style u_qm_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 16
    kerning 3
    color "#94837d"
    hover_color "#f2c4a5"
    selected_color "#e8a27a"

screen quick_menu():
    zorder 100
    if quick_menu and renpy.get_screen("say") and not (renpy.get_screen("chapter_banner") or renpy.get_screen("choice") or renpy.get_screen("ending_card") or renpy.get_screen("content_notice")):
        hbox:
            xalign 0.5
            ypos 1036
            spacing 26
            textbutton "НАЗАД" action Rollback() style "u_qm"
            textbutton "ИСТОРИЯ" action ShowMenu("history") style "u_qm"
            textbutton "ПРОПУСК" action Skip() alternate Skip(fast=True, confirm=True) style "u_qm"
            textbutton "АВТО" action Preference("auto-forward", "toggle") style "u_qm"
            textbutton "СОХРАНИТЬ" action ShowMenu("save") style "u_qm"
            textbutton "ЗАГРУЗИТЬ" action ShowMenu("load") style "u_qm"
            textbutton "НАСТРОЙКИ" action ShowMenu("preferences") style "u_qm"
            textbutton "СКРЫТЬ" action HideInterface() style "u_qm"

## ---------------------------------------------------------------- choices

style u_choice is u_button:
    background Frame("images/ui/fr_choice.png", 8, 8)
    hover_background Frame("images/ui/fr_choice_h.png", 8, 8)
    xsize 1180
    padding (46, 26)
    xalign 0.5

style u_choice_num is default:
    font "fonts/Manrope-SemiBold.ttf"
    size 16
    kerning 2
    color "#8c7a74"
    hover_color "#f0a77e"
    min_width 30

style u_choice_text is default:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 37
    color "#e6d9ce"
    hover_color "#fff5eb"
    xmaximum 1000
    line_spacing 0

screen choice(items):
    add Solid("#07050a8a") at u_dim_in
    vbox:
        xalign 0.5
        yalign 0.47
        spacing 16
        text "ВАШ ВЫБОР" style "u_eyebrow" xalign 0.5 at u_fade(0.0, 0.5)
        add "images/ui/rule_c.png" xalign 0.5 xsize 420 at u_grow_c(0.05, 0.8)
        null height 20
        for i, item in enumerate(items):
            button:
                style "u_choice"
                action item.action
                alt item.caption
                at u_rise(0.14 + i * 0.08, 0.55, 18)
                hbox:
                    spacing 26
                    text ("%02d" % (i + 1)) style "u_choice_num" yalign 0.5
                    text item.caption style "u_choice_text" yalign 0.5 at u_shift(10)
    for i, item in enumerate(items[:9]):
        key str(i + 1) action item.action

## ---------------------------------------------------------------- chapter card

screen chapter_banner(title, subtitle):
    zorder 110
    add "unlived_ambient"
    add "unlived_grain_fx"
    vbox:
        xalign 0.5
        yalign 0.47
        spacing 0
        text title.upper() style "u_eyebrow" size 18 kerning 10 xalign 0.5 at u_fade(0.15, 0.7)
        null height 28
        add "images/ui/rule_c.png" xalign 0.5 xsize 520 at u_grow_c(0.3, 1.1)
        null height 26
        text subtitle style "u_title" size 94 xalign 0.5 text_align 0.5 xmaximum 1560 at u_rise(0.4, 1.1, 22)

## ---------------------------------------------------------------- ending card

screen ending_card(number, title):
    modal True
    zorder 120
    $ opened = len(persistent.unlived_endings)
    add "unlived_ambient"
    add "unlived_grain_fx"
    vbox:
        xalign 0.5
        yalign 0.46
        spacing 0
        text ("КОНЦОВКА  " + unlived_roman.get(number, str(number)) + "   ·   ИЗ  IV") style "u_eyebrow" size 18 kerning 8 xalign 0.5 at u_fade(0.3, 0.9)
        null height 30
        text title style "u_title" size 82 xalign 0.5 text_align 0.5 xmaximum 1500 at u_rise(0.6, 1.3, 26)
        null height 36
        add "images/ui/rule_c.png" xalign 0.5 xsize 560 at u_grow_c(1.1, 1.2)
        null height 36
        text "Спасибо за прохождение." style "u_body" font "fonts/Lora-Italic.ttf" size 28 xalign 0.5 at u_fade(1.5, 1.0)
        null height 12
        text ("Открыто концовок: %d из 4" % opened) style "u_note" xalign 0.5 at u_fade(1.7, 1.0)
        null height 54
        textbutton "В ГЛАВНОЕ МЕНЮ" action Return() style "u_btn" xalign 0.5 at u_fade(2.1, 0.8)

## ---------------------------------------------------------------- notifications

transform u_notify_t:
    subpixel True
    on show:
        alpha 0.0
        yoffset -14
        parallel:
            easein_cubic 0.4 yoffset 0
        parallel:
            easein 0.3 alpha 1.0
    on hide:
        easeout 0.3 alpha 0.0

screen notify(message):
    zorder 100
    frame:
        at u_notify_t
        xalign 0.5
        ypos 44
        background Frame("images/ui/fr_pill.png", 18, 18)
        padding (34, 14, 36, 15)
        hbox:
            spacing 14
            add "images/ui/diamond.png" zoom 0.6 yalign 0.5
            text "[message!tq]" style "u_label" size 20
    timer 3.25 action Hide("notify")

screen skip_indicator():
    zorder 100
    hbox:
        at u_fade(0.0, 0.3)
        xanchor 1.0
        xpos 1828
        ypos 54
        spacing 8
        text "ПРОПУСК" style "u_eyebrow" size 15 yalign 0.5
        text "›" style "u_value" size 24 at u_blink(0.0, 1.0)
        text "›" style "u_value" size 24 at u_blink(0.2, 1.0)
        text "›" style "u_value" size 24 at u_blink(0.4, 1.0)
