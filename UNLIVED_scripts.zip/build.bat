@echo off
chcp 65001 >nul
cd /d "%~dp0"
title UNLIVED - сборка установщика

call :find_iscc
if defined ISCC goto build

echo Inno Setup 6 не найден. Пробую установить его через winget...
winget install -e --id JRSoftware.InnoSetup --accept-source-agreements --accept-package-agreements
call :find_iscc
if defined ISCC goto build

echo.
echo Не удалось найти Inno Setup 6.
echo Скачайте его бесплатно: https://jrsoftware.org/isdl.php
echo После установки снова запустите build.bat
pause
exit /b 1

:build
echo Найден компилятор: %ISCC%
echo Собираю UNLIVED-Setup-0.2.0.exe ...
"%ISCC%" "%~dp0UNLIVED.iss"
if errorlevel 1 (
  echo.
  echo Ошибка сборки. Пришлите текст выше - разберёмся.
  pause
  exit /b 1
)
echo.
echo Готово! Установщик лежит в папке Output.
start "" explorer "%~dp0Output"
pause
exit /b 0

:find_iscc
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
exit /b 0
