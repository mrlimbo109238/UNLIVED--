﻿; =====================================================================
;  UNLIVED · Грехи желаний — установщик для Windows (Inno Setup 6)
;  Сборка: запустите build.bat (или откройте этот файл в Inno Setup
;  и нажмите Build -> Compile). Результат: Output\UNLIVED-Setup-0.2.0.exe
; =====================================================================

#define AppName      "UNLIVED"
#define AppSubtitle  "Грехи желаний"
#define AppVersion   "0.2.0"
#define AppPublisher "UNLIVED"
#define AppExe       "UNLIVED.exe"

[Setup]
AppId={{B7E3A1C4-5D2F-4E8A-9C61-3F0A7D2E9B14}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
VersionInfoVersion={#AppVersion}
VersionInfoDescription={#AppName} — установщик

; Путь по умолчанию; пользователь может выбрать любой другой
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
DisableWelcomePage=no
DisableDirPage=no
DisableReadyPage=no
ShowLanguageDialog=no

; Без прав администратора по умолчанию, но можно выбрать «для всех пользователей»
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

; Один exe-файл на выходе
OutputDir=Output
OutputBaseFilename=UNLIVED-Setup-{#AppVersion}
Compression=lzma2/ultra64
SolidCompression=yes
LZMANumBlockThreads=4

; Внешний вид в стиле игры
#if Ver >= EncodeVer(6,5,0)
WizardStyle=modern dark
#else
WizardStyle=modern
#endif
WizardImageFile=assets\wizard_164.bmp,assets\wizard_246.bmp,assets\wizard_328.bmp,assets\wizard_410.bmp
WizardSmallImageFile=assets\small_55.bmp,assets\small_83.bmp,assets\small_110.bmp,assets\small_138.bmp
WizardImageStretch=yes
SetupIconFile=assets\unlived.ico
UninstallDisplayIcon={app}\unlived.ico
UninstallDisplayName={#AppName} · {#AppSubtitle}
CloseApplications=yes

[Languages]
Name: "ru"; MessagesFile: "compiler:Languages\Russian.isl"

[LangOptions]
WelcomeFontName=Georgia
WelcomeFontSize=15
TitleFontName=Georgia

[Messages]
SetupWindowTitle=Установка — %1
WelcomeLabel1=UNLIVED%nГрехи желаний
WelcomeLabel2=Психологическая визуальная новелла.%n%nМастер установит игру на ваш компьютер и создаст ярлык с иконкой игры на рабочем столе — дальше достаточно одного двойного клика.%n%nНажмите «Далее», чтобы продолжить.
SelectDirDesc=Где будет жить история?
SelectDirLabel3=UNLIVED будет установлена в указанную папку.
ReadyLabel1=Всё готово к установке UNLIVED.
InstallingLabel=Подождите, пока UNLIVED устанавливается на ваш компьютер…
FinishedHeadingLabel=История готова начаться
FinishedLabel=UNLIVED установлена. Ярлык с иконкой игры уже на рабочем столе.
FinishedLabelNoIcons=UNLIVED установлена.

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Ярлыки:"

[Dirs]
Name: "{app}"; Permissions: users-modify; Check: IsAdminInstallMode

[Files]
Source: "game_files\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "assets\unlived.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; IconFilename: "{app}\unlived.ico"; Comment: "{#AppName} · {#AppSubtitle}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; IconFilename: "{app}\unlived.ico"; Comment: "{#AppName} · {#AppSubtitle}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; Description: "Запустить UNLIVED"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\game\cache"
Type: filesandordirs; Name: "{app}\game\saves"
Type: files; Name: "{app}\log.txt"
Type: files; Name: "{app}\traceback.txt"
Type: files; Name: "{app}\errors.txt"
Type: dirifempty; Name: "{app}"

[Code]
const
  { Цвета в формате $00BBGGRR — палитра главного меню игры }
  CBg     = $00120A0E;  { #0e0a12 — фон }
  CPanel  = $001D1419;  { #19141d — верхняя панель }
  CEdit   = $00261C22;  { #221c26 — поля ввода }
  CText   = $00DCE8F3;  { #f3e8dc — основной текст }
  CMuted  = $009CA5B8;  { #b8a59c — вторичный текст }
  CAccent = $007EA7F0;  { #f0a77e — акцент }

procedure InitializeWizard;
begin
  WizardForm.Color := CBg;
  WizardForm.Font.Color := CText;
  WizardForm.MainPanel.Color := CPanel;

  WizardForm.WelcomePage.Color := CBg;
  WizardForm.InnerPage.Color := CBg;
  WizardForm.FinishedPage.Color := CBg;
  WizardForm.SelectDirPage.Color := CBg;
  WizardForm.SelectTasksPage.Color := CBg;
  WizardForm.ReadyPage.Color := CBg;
  WizardForm.PreparingPage.Color := CBg;
  WizardForm.InstallingPage.Color := CBg;

  WizardForm.PageNameLabel.Font.Name := 'Georgia';
  WizardForm.PageNameLabel.Font.Color := CText;
  WizardForm.PageDescriptionLabel.Font.Color := CMuted;

  WizardForm.WelcomeLabel1.Font.Color := CText;
  WizardForm.WelcomeLabel2.Font.Color := CMuted;
  WizardForm.FinishedHeadingLabel.Font.Color := CText;
  WizardForm.FinishedLabel.Font.Color := CMuted;

  WizardForm.SelectDirLabel.Font.Color := CText;
  WizardForm.SelectDirBrowseLabel.Font.Color := CMuted;
  WizardForm.DiskSpaceLabel.Font.Color := CAccent;
  WizardForm.DirEdit.Color := CEdit;
  WizardForm.DirEdit.Font.Color := CText;

  WizardForm.SelectTasksLabel.Font.Color := CText;
  WizardForm.TasksList.Color := CBg;
  WizardForm.TasksList.Font.Color := CText;

  WizardForm.ReadyLabel.Font.Color := CText;
  WizardForm.ReadyMemo.Color := CEdit;
  WizardForm.ReadyMemo.Font.Color := CText;

  WizardForm.PreparingLabel.Font.Color := CText;
  WizardForm.StatusLabel.Font.Color := CText;
  WizardForm.FilenameLabel.Font.Color := CMuted;

  WizardForm.RunList.Color := CBg;
  WizardForm.RunList.Font.Color := CText;
end;
