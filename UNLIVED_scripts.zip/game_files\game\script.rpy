# UNLIVED. See game/scripts/story.rpy and game/scripts/ui.rpy.
