## UNLIVED — interface core: data, helpers, motion and typography.
##
## Type system
##   Display / titles ...... Cormorant Garamond Light
##   Menu items, names ..... Cormorant Garamond Medium / SemiBold
##   Interface labels ...... Manrope (uppercase, tracked eyebrows)
##   Dialogue .............. Lora (thoughts: Lora Italic)
##   Handwritten accents ... Marck Script
init offset = 10

define ending_titles = {
    1: "Ведь я — это ты",
    2: "Прости, Надя",
    3: "Закрывается одна дверь и открывается другая",
    4: "Я буду помнить тебя, но с улыбкой"
}
define unlived_ending_paths = {1: "Путь тьмы", 2: "Путь тьмы", 3: "Путь света", 4: "Путь света"}
define unlived_roman = {1: "I", 2: "II", 3: "III", 4: "IV"}

default persistent.unlived_parallax = True
default persistent.unlived_fx = True
default persistent.unlived_cw_ack = False

init python:
    import math

    # Once-per-update migration: removes an old low-FPS/powersave preference, not saves.
    if not persistent.unlived_smooth_ui_1:
        preferences.gl_framerate = None
        preferences.gl_powersave = False
        persistent.unlived_smooth_ui_1 = True

    class UnlivedSession(NoRollback):
        """Per-launch memory (never saved): has the full menu intro already played?"""
        menu_seen = False

    def unlived_mark_menu_seen():
        UnlivedSession.menu_seen = True

    # Save files remember the chapter, so slots can show where the story stopped.
    def unlived_save_json(d):
        d["chapter"] = getattr(store, "chapter_title", "") or ""
    config.save_json_callbacks.append(unlived_save_json)

    def unlived_split_chapter(ct):
        """'Глава 1 / Лето 2009 года' -> ('Глава 1', 'Лето 2009 года')."""
        if not ct:
            return ("", "")
        if " / " in ct:
            a, b = ct.split(" / ", 1)
            return (a, b)
        return (ct, "")

    def unlived_chapter_caps(ct):
        a, b = unlived_split_chapter(ct)
        return (a + ("   ·   " + b if b else "")).upper()

    def unlived_slot_chapter(slot, full=False):
        ct = FileJson(slot, "chapter", empty="", missing="", slot=full)
        return ct if ct else "Сохранение"

    def unlived_newest_slot():
        try:
            s = renpy.newest_slot(r"(\d+-\d+|auto-\d+|quick-\d+)$")
        except Exception:
            s = None
        if s is not None and renpy.can_load(s):
            return s
        return None

    def unlived_cps_text():
        cps = preferences.text_cps
        return "Мгновенно" if not cps else "%d зн./с" % cps

    def unlived_afm_text():
        t = preferences.afm_time
        if not t or t >= 30:
            return "Медленно"
        return "%.0f из 30" % t

    def unlived_pct(mixer):
        try:
            return "%d%%" % int(round(preferences.get_mixer(mixer) * 100))
        except Exception:
            return ""

    def unlived_renderer_name():
        r = renpy.get_renderer_info().get("renderer", "")
        return {"gl2": "OpenGL", "gles2": "OpenGL ES", "angle2": "DirectX (ANGLE)", "sw": "программный"}.get(r, r or "не определён")

## ---------------------------------------------------------------- motion

transform u_fade(delay=0.0, dur=0.5):
    alpha 0.0
    pause delay
    easein dur alpha 1.0

transform u_rise(delay=0.0, dur=0.7, dy=18):
    subpixel True
    alpha 0.0
    yoffset dy
    pause delay
    parallel:
        easein_cubic dur yoffset 0
    parallel:
        easein (dur * 0.8) alpha 1.0

transform u_slide(delay=0.0, dur=0.6, dx=-28):
    subpixel True
    alpha 0.0
    xoffset dx
    pause delay
    parallel:
        easein_cubic dur xoffset 0
    parallel:
        easein (dur * 0.8) alpha 1.0

transform u_grow(delay=0.0, dur=0.9):
    subpixel True
    xzoom 0.0
    alpha 0.0
    pause delay
    parallel:
        easein_quart dur xzoom 1.0
    parallel:
        easein (dur * 0.4) alpha 1.0

transform u_grow_c(delay=0.0, dur=1.0):
    subpixel True
    xanchor 0.5
    xzoom 0.0
    alpha 0.0
    pause delay
    parallel:
        easein_quart dur xzoom 1.0
    parallel:
        easein (dur * 0.4) alpha 1.0

transform u_modal_in:
    subpixel True
    on show:
        alpha 0.0
        zoom 0.97
        yoffset 12
        parallel:
            easein_cubic 0.32 zoom 1.0 yoffset 0
        parallel:
            easein 0.25 alpha 1.0
    on hide:
        easeout 0.18 alpha 0.0 zoom 0.985

transform u_dim_in:
    on show:
        alpha 0.0
        easein 0.25 alpha 1.0
    on hide:
        easeout 0.2 alpha 0.0

transform u_blink(delay, cycle):
    alpha 0.25
    pause delay
    block:
        easein 0.25 alpha 1.0
        pause 0.15
        easeout 0.25 alpha 0.25
        pause (cycle - 0.4)
        repeat

## Hover choreography (events are delivered by the enclosing button).
transform u_shift(dx=14):
    subpixel True
    on idle, selected_idle, insensitive, selected_insensitive:
        easein_cubic 0.35 xoffset 0
    on hover, selected_hover:
        easein_cubic 0.35 xoffset dx

transform u_show_on_hover:
    alpha 0.0
    on idle, selected_idle, insensitive, selected_insensitive:
        easein 0.35 alpha 0.0
    on hover, selected_hover:
        easein 0.25 alpha 1.0

transform u_line_on_hover:
    subpixel True
    xzoom 0.0
    alpha 0.0
    on idle, selected_idle, insensitive, selected_insensitive:
        easein_cubic 0.3 xzoom 0.0 alpha 0.0
    on hover, selected_hover:
        easein_cubic 0.4 xzoom 1.0 alpha 1.0

transform u_show_on_selected:
    alpha 0.0
    on idle, hover, insensitive:
        easein 0.25 alpha 0.0
    on selected_idle, selected_hover, selected_insensitive:
        easein 0.3 alpha 1.0

transform u_line_on_selected:
    subpixel True
    xzoom 0.0
    alpha 0.0
    on idle, hover, insensitive:
        easein_cubic 0.25 xzoom 0.0 alpha 0.0
    on selected_idle, selected_hover, selected_insensitive:
        easein_cubic 0.4 xzoom 1.0 alpha 1.0

transform u_lift:
    subpixel True
    on idle, selected_idle, insensitive:
        easein_cubic 0.3 yoffset 0
    on hover, selected_hover:
        easein_cubic 0.3 yoffset -6

transform u_knob:
    subpixel True
    ypos 4
    xpos 4
    on idle, hover, insensitive:
        easein_cubic 0.24 xpos 4
    on selected_idle, selected_hover, selected_insensitive:
        easein_cubic 0.24 xpos 34

## ---------------------------------------------------------------- type

style u_text is default:
    font "fonts/Manrope-Regular.ttf"
    size 22
    color "#e9ddd2"
    line_spacing 6

style u_eyebrow is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 17
    kerning 6
    color "#dca78a"

style u_eyebrow_dim is u_eyebrow:
    color "#8c7a75"

style u_title is u_text:
    font "fonts/CormorantGaramond-Light.ttf"
    size 96
    kerning 1
    color "#f1e6da"
    line_spacing 0

style u_h2 is u_text:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 40
    color "#f1e6da"
    line_spacing 0

style u_h3 is u_text:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 32
    color "#efe3d6"
    line_spacing 0

style u_body is u_text:
    font "fonts/Lora-Regular.ttf"
    size 25
    color "#e4d7cc"
    line_spacing 10

style u_note is u_text:
    size 20
    color "#a6948d"
    line_spacing 6

style u_label is u_text:
    font "fonts/Manrope-Medium.ttf"
    size 23
    color "#e9ddd2"

style u_value is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 19
    kerning 1
    color "#e8a27a"

style u_hand is u_text:
    font "fonts/MarckScript-Regular.ttf"
    size 44
    color "#f0bf9e"
    line_spacing 0

## ---------------------------------------------------------------- controls

style u_button is default:
    hover_sound "audio/ui/ux_hover.ogg"
    activate_sound "audio/ui/ux_select.ogg"
    background None
    padding (0, 0)

style u_button_text is u_text

# Outline call-to-action button.
style u_btn is u_button:
    background Frame("images/ui/fr_btn.png", 8, 8)
    hover_background Frame("images/ui/fr_btn_h.png", 8, 8)
    padding (44, 18)
    xminimum 220

style u_btn_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 18
    kerning 4
    color "#efe3d6"
    hover_color "#ffe9d8"
    xalign 0.5
    text_align 0.5

# Quiet text link.
style u_link is u_button

style u_link_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 17
    kerning 4
    color "#9c8a84"
    hover_color "#f2c4a5"
    selected_color "#e8a27a"
    insensitive_color "#5c4f4d"

# Segmented options.
style u_seg is u_button:
    background Frame("images/ui/fr_seg.png", 8, 8)
    hover_background Frame("images/ui/fr_seg_h.png", 8, 8)
    selected_background Frame("images/ui/fr_seg_sel.png", 8, 8)
    selected_hover_background Frame("images/ui/fr_seg_sel.png", 8, 8)
    padding (28, 13)
    activate_sound "audio/ui/ux_toggle.ogg"

style u_seg_text is u_text:
    font "fonts/Manrope-Medium.ttf"
    size 20
    color "#b3a29a"
    hover_color "#f1e6da"
    selected_color "#ffe3cf"
    xalign 0.5

# Tabs.
style u_tab is u_button:
    activate_sound "audio/ui/ux_toggle.ogg"
    padding (0, 6)

style u_tab_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 18
    kerning 4
    color "#8f7d77"
    hover_color "#efe3d6"
    selected_color "#f2c4a5"

# Toggle rows.
style u_toggle is u_button:
    activate_sound "audio/ui/ux_toggle.ogg"
    padding (0, 4)

style u_row_label is u_label:
    hover_color "#ffffff"

style u_row_note is u_note:
    size 18
    color "#8f7e78"

# Sliders.
style u_bar is default:
    xsize 520
    ysize 36
    left_bar Frame("images/ui/sl_fill.png", 6, 0)
    right_bar Frame("images/ui/sl_track.png", 6, 0)
    thumb "images/ui/sl_thumb.png"
    hover_thumb "images/ui/sl_thumb_h.png"
    thumb_offset 18
    left_gutter 0
    right_gutter 0
    hover_sound None

style u_vscroll is default:
    xsize 6
    base_bar Frame("images/ui/sl_track_v.png", 0, 6)
    thumb Frame("images/ui/sl_fill_v.png", 0, 6)
    unscrollable "hide"

style vscrollbar:
    xsize 6
    base_bar Frame("images/ui/sl_track_v.png", 0, 6)
    thumb Frame("images/ui/sl_fill_v.png", 0, 6)
    unscrollable "hide"

style scrollbar:
    ysize 6
    base_bar Solid("#efe3d61c")
    thumb Solid("#e8a27a")
    unscrollable "hide"

style u_key is default:
    background Frame("images/ui/fr_key.png", 10, 10)
    padding (16, 11, 16, 9)
    xminimum 54

style u_key_text is u_text:
    font "fonts/Manrope-SemiBold.ttf"
    size 18
    kerning 1
    color "#f1e6da"
    xalign 0.5

style u_panel is default:
    background Frame("images/ui/fr_panel.png", 10, 10)
    padding (72, 58)

style hyperlink_text:
    color "#f2c4a5"
    hover_color "#ffffff"
    hover_underline True

## ---------------------------------------------------------------- components

## A settings row: label (with optional note) on the left, control on the right.
screen u_row(label, note=None):
    hbox:
        xsize 1220
        box_align 0.0
        spacing 40
        vbox:
            xsize 420
            yalign 0.5
            spacing 4
            text label style "u_label"
            if note:
                text note style "u_row_note"
        hbox:
            yalign 0.5
            spacing 12
            transclude

## Segmented control: [(caption, action), ...]
screen u_seg(options):
    hbox:
        spacing 10
        for caption, act in options:
            textbutton caption action act style "u_seg"

## Switch with an animated knob; the label is part of the hit area.
screen u_toggle(label, action, note=None):
    button:
        style "u_toggle"
        action action
        xsize 1220
        hbox:
            spacing 40
            vbox:
                xsize 420
                yalign 0.5
                spacing 4
                text label style "u_row_label"
                if note:
                    text note style "u_row_note"
            fixed:
                xysize (64, 34)
                yalign 0.5
                add "images/ui/tg_off.png"
                add "images/ui/tg_on.png" at u_show_on_selected
                add "images/ui/tg_knob.png" at u_knob

## Slider row with a live value readout.
screen u_slider(label, value, shown="", note=None):
    hbox:
        xsize 1220
        box_align 0.0
        spacing 40
        vbox:
            xsize 420
            yalign 0.5
            spacing 4
            text label style "u_label"
            if note:
                text note style "u_row_note"
        bar value value style "u_bar" yalign 0.5
        text shown style "u_value" yalign 0.5 min_width 150

## Tabs with an accent underline on the selected one.
screen u_tabs(items, current, var):
    hbox:
        spacing 44
        for key, caption in items:
            button:
                style "u_tab"
                action SetScreenVariable(var, key)
                selected (current == key)
                vbox:
                    spacing 12
                    text caption.upper() style "u_tab_text"
                    add "images/ui/line_accent.png" xsize 34 ysize 2 at u_line_on_selected

screen u_key(label):
    frame:
        style "u_key"
        text label style "u_key_text"

## The section header used inside menus.
screen u_section(caption):
    hbox:
        spacing 16
        add "images/ui/diamond.png" zoom 0.55 yalign 0.5
        text caption.upper() style "u_eyebrow"
