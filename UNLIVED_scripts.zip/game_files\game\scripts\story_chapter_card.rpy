label chapter_card(title, subtitle):
    window hide
    show screen chapter_banner(title, subtitle)
    with Dissolve(0.3)
    pause 2.4
    hide screen chapter_banner
    with Dissolve(0.3)
    return
