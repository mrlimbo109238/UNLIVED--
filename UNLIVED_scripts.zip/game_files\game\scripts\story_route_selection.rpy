label route_selection:
    if light_points > dark_points or (light_points == dark_points and last_choice_light):
        if nadya_route:
            jump chapter_four_light_nadya
        jump chapter_four_light_solo
    if nadya_route:
        jump chapter_four_dark_nadya
    jump chapter_four_dark_solo

