## UNLIVED — main menu, first-launch notice, new-game threshold.
init offset = 12

transform um_letter(delay, dur):
    subpixel True
    alpha 0.0
    yoffset 34
    pause delay
    parallel:
        easein_quart dur yoffset 0
    parallel:
        easein (dur * 0.75) alpha 1.0

## "UN" stays half-lit and slowly breathes: a life not quite lived.
transform um_letter_dim(delay, dur):
    subpixel True
    alpha 0.0
    yoffset 34
    pause delay
    parallel:
        easein_quart dur yoffset 0
    parallel:
        easein (dur * 0.75) alpha 0.58
    block:
        ease 3.4 alpha 0.32
        ease 3.4 alpha 0.58
        repeat

transform um_item_in(delay, dur):
    subpixel True
    alpha 0.0
    xoffset -30
    pause delay
    parallel:
        easein_cubic dur xoffset 0
    parallel:
        easein (dur * 0.8) alpha 1.0

transform um_desc:
    subpixel True
    on appear:
        alpha 1.0
    on show:
        alpha 0.0
        xoffset -12
        parallel:
            easein_cubic 0.4 xoffset 0
        parallel:
            easein 0.3 alpha 1.0
    on hide:
        easeout 0.18 alpha 0.0

style um_logo is default:
    font "fonts/CormorantGaramond-Light.ttf"
    size 150
    color "#f3e8dc"
    outlines [(absolute(6), "#0b081033", absolute(0), absolute(3))]

style um_logo_dim is um_logo:
    color "#c9a99b"

style um_item_text is default:
    font "fonts/CormorantGaramond-Medium.ttf"
    size 46
    color "#d9cbc1"
    hover_color "#fff4ea"
    outlines [(absolute(3), "#0b081040", absolute(0), absolute(1))]

style um_item_index is default:
    font "fonts/Manrope-SemiBold.ttf"
    size 16
    kerning 2
    color "#7d6c68"
    hover_color "#f0a77e"

style um_desc is default:
    font "fonts/Manrope-Regular.ttf"
    size 21
    color "#b8a59c"

style um_footer is default:
    font "fonts/Manrope-SemiBold.ttf"
    size 16
    kerning 4
    color "#7b6a66"

style um_epi is default:
    font "fonts/CormorantGaramond-Italic.ttf"
    size 34
    color "#d8c4b8"
    outlines [(absolute(4), "#0b081055", absolute(0), absolute(2))]

## One menu entry: index, growing accent line, caption that slides on hover.
screen um_item(index, caption, action, key, delay, dur):
    button:
        style "u_button"
        action action
        tooltip key
        alt caption
        xsize 660
        ysize 58
        at um_item_in(delay, dur)
        fixed:
            add "images/ui/hl_bar.png" xpos -46 yalign 0.5 at u_show_on_hover
            text ("%02d" % index) style "um_item_index" xpos 0 yalign 0.5 yoffset 2
            add "images/ui/line_accent.png" xpos 40 yalign 0.5 xsize 30 ysize 2 at u_line_on_hover
            text caption style "um_item_text" xpos 64 yalign 0.5 at u_shift(22)

screen main_menu():
    tag menu

    default full = not UnlivedSession.menu_seen
    on "show" action Function(unlived_mark_menu_seen)
    on "replaced" action Function(unlived_mark_menu_seen)

    python:
        k = 1.0 if full else 0.0
        newest = unlived_newest_slot()
        opened = len(persistent.unlived_endings)
        entries = []
        if newest is not None:
            entries.append(("Продолжить", FileLoad(newest, slot=True, confirm=False), "continue"))
        entries.append(("Новая игра", Start("unlived_new_game"), "new"))
        entries.append(("Загрузить", ShowMenu("load"), "load"))
        entries.append(("Настройки", ShowMenu("preferences"), "prefs"))
        entries.append(("Концовки", ShowMenu("endings_gallery"), "endings"))
        entries.append(("Об игре", ShowMenu("about"), "about"))
        if newest is not None:
            ct = unlived_slot_chapter(newest, True)
            cont_desc = ct.replace(" / ", " · ") + "  —  " + FileTime(newest, format="%d.%m.%Y, %H:%M", slot=True)
        else:
            cont_desc = ""
        descs = {
            "continue": cont_desc,
            "new": "Начать историю Луки с пролога",
            "load": "Выбрать сохранённый момент истории",
            "prefs": "Текст, звук, графика и доступность",
            "endings": "Открыто концовок: %d из 4" % opened,
            "about": "История, создатели и предупреждение о содержании",
            "quit": "Закрыть игру",
        }
        tip = GetTooltip()
        menu_y = 528 if newest is None else 508

    ## the living room
    add "unlived_menu_scene" at (unlived_cam_full if full else unlived_cam_return)
    add "images/ui/grad_left.png" at u_fade(0.0, 1.6 * k + 0.3)
    add "unlived_grain_fx"
    add "images/ui/vignette.png"

    ## title block

    hbox:
        pos (142, 196)
        spacing 4
        for i, ch in enumerate("UNLIVED"):
            if i < 2:
                text ch style "um_logo_dim" at um_letter_dim(0.75 * k + i * 0.09 * k, 1.3 * k + 0.35)
            else:
                text ch style "um_logo" at um_letter(0.75 * k + i * 0.09 * k, 1.3 * k + 0.35)

    add "images/ui/diamond.png" pos (150, 392) at u_fade(1.45 * k, 0.6 * k + 0.25)
    add "images/ui/rule.png" pos (176, 399) xsize 400 at u_grow(1.5 * k, 1.2 * k + 0.4)

    text "Грехи желаний" style "u_hand" size 52 pos (152, 418) at u_slide(1.7 * k, 1.1 * k + 0.35, -14)

    ## menu
    vbox:
        pos (150, menu_y)
        spacing 0
        for i, (caption, act, key) in enumerate(entries):
            use um_item(i + 1, caption, act, key, (2.0 + i * 0.075) * k, 0.7 * k + 0.3)
        null height 16
        use um_item(len(entries) + 1, "Выйти", Quit(confirm=False), "quit", (2.0 + len(entries) * 0.075 + 0.1) * k, 0.7 * k + 0.3)

    ## description of the focused entry
    fixed:
        xpos 214
        ypos (menu_y + 58 * (len(entries) + 1) + 16 + 20)
        xysize (900, 40)
        for key, d in descs.items():
            showif tip == key and d:
                text d style "um_desc" at um_desc

    ## footer
    hbox:
        pos (156, 1022)
        spacing 18
        at u_fade(2.6 * k, 0.8 * k + 0.3)
        text ("ВЕРСИЯ " + config.version) style "um_footer"
        add "images/ui/diamond.png" zoom 0.42 yalign 0.5
        text "18+" style "um_footer"


    key "game_menu" action NullAction()


## ------------------------------------------------------------ first launch

screen content_notice():
    modal True
    zorder 150
    add "unlived_ambient"
    add "unlived_grain_fx"
    vbox:
        xalign 0.5
        yalign 0.46
        xsize 1180
        spacing 0
        text "ПЕРЕД НАЧАЛОМ" style "u_eyebrow" xalign 0.5 at u_fade(0.3, 0.8)
        null height 30
        text "Эта история — для взрослой аудитории" style "u_title" size 70 xalign 0.5 text_align 0.5 at u_rise(0.5, 1.0, 20)
        null height 30
        add "images/ui/rule_c.png" xalign 0.5 xsize 620 at u_grow_c(0.9, 1.1)
        null height 38
        text "В тексте присутствуют семейное и сексуальное насилие, травля, смерть близких, психические расстройства, самоповреждение и суицид. Некоторые сцены содержат грубую лексику и тяжёлые подробности.":
            style "u_body"
            xalign 0.5
            text_align 0.5
            at u_fade(1.2, 0.9)
        null height 22
        text "Если эти темы могут причинить вам вред, пожалуйста, откажитесь от прохождения. Игра не является рекомендацией по лечению.":
            style "u_note"
            size 21
            xalign 0.5
            text_align 0.5
            at u_fade(1.4, 0.9)
        null height 54
        hbox:
            xalign 0.5
            spacing 26
            at u_fade(1.8, 0.8)
            textbutton "МНЕ ЕСТЬ 18 ЛЕТ — ПРОДОЛЖИТЬ" action Return(True) style "u_btn"
            textbutton "ВЫЙТИ" action Return(False) style "u_btn"
    key "game_menu" action NullAction()

label splashscreen:
    if not persistent.unlived_cw_ack:
        scene black
        call screen content_notice with Dissolve(0.8)
        if _return:
            $ persistent.unlived_cw_ack = True
            $ renpy.save_persistent()
        else:
            $ renpy.quit()
        scene black
        with Dissolve(0.6)
    return


## ------------------------------------------------------------ new game

label unlived_new_game:
    play sound "audio/ui/ux_start.ogg"
    jump start
