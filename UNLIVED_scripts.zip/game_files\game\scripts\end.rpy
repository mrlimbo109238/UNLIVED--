# The four author endings are in scripts/story.rpy.
