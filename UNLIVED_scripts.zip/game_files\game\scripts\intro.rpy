## Вступительное видео. Перед ним — короткий экран подготовки.
## Удерживайте пробел, чтобы пропустить само видео.

define UNLIVED_INTRO_VIDEO = "videos/intro.webm"
define UNLIVED_INTRO_AUDIO = "audio/intro/intro.ogg"
define UNLIVED_INTRO_LENGTH = 156.6
define UNLIVED_INTRO_LOADING_TIME = 6.0
define UNLIVED_HOLD_TIME = 1.5

transform unlived_intro_loading_line:
    xzoom 0.0
    linear UNLIVED_INTRO_LOADING_TIME xzoom 1.0

screen unlived_intro_loading():
    modal True
    zorder 200

    add "unlived_ambient"
    add "unlived_grain_fx"

    vbox:
        xalign 0.5
        yalign 0.48
        spacing 0
        text "UNLIVED" style "u_title" size 82 xalign 0.5 at u_fade(0.1, 0.8)
        null height 5
        text "Грехи желаний" style "u_hand" size 36 xalign 0.5 at u_fade(0.35, 0.8)
        null height 52
        text "ЗАГРУЗКА ИНТРО" style "u_eyebrow" size 15 xalign 0.5 at u_fade(0.55, 0.7)
        null height 24
        fixed:
            xalign 0.5
            xysize (320, 2)
            add Solid("#e9ddd233", xsize=320, ysize=2)
            add Solid("#dca78a", xsize=320, ysize=2) at unlived_intro_loading_line
        null height 18
        text "История скоро начнётся" style "u_note" size 18 xalign 0.5 at u_fade(0.8, 0.7)

    timer UNLIVED_INTRO_LOADING_TIME action Return()
    key "dismiss" action NullAction()
    key "game_menu" action NullAction()
    key "skip" action NullAction()
    key "toggle_skip" action NullAction()

init python:
    import pygame

    # Дорожка видео остаётся беззвучной: звук воспроизводится отдельно,
    # но синхронно с ней. Оба канала подчиняются громкости музыки.
    renpy.music.register_channel("unlived_intro_audio", mixer="music", loop=False, stop_on_mute=False)

    def unlived_play_intro(old, new):
        renpy.music.play(new._play, channel=new.channel, loop=False,
                         synchro_start=True, fadeout=0, relative_volume=0.0)
        renpy.music.play(UNLIVED_INTRO_AUDIO, channel="unlived_intro_audio", loop=False,
                         synchro_start=True, fadeout=0)

    class UnlivedHoldToSkip(renpy.Displayable):
        """Компактная подсказка и индикатор удержания пробела."""

        def __init__(self, hold_time=1.5, **kwargs):
            super(UnlivedHoldToSkip, self).__init__(**kwargs)
            self.hold_time = hold_time
            self.held = False
            self.hold_start = None
            self.progress = 0.0
            self.label = Text(
                "УДЕРЖИВАЙТЕ ПРОБЕЛ",
                font="fonts/Manrope-SemiBold.ttf",
                size=15,
                kerning=1.2,
                color="#e9ddd2",
            )
            self.caption = Text(
                "чтобы пропустить интро",
                font="fonts/CormorantGaramond-Italic.ttf",
                size=21,
                color="#c6b1a6",
            )

        def event(self, ev, x, y, st):
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_SPACE:
                if not self.held:
                    self.held = True
                    self.hold_start = st
                renpy.redraw(self, 0)
                raise renpy.IgnoreEvent()

            if ((ev.type == pygame.KEYUP and ev.key == pygame.K_SPACE) or
                    ev.type == getattr(pygame, "WINDOWFOCUSLOST", -1)):
                self.held = False
                self.hold_start = None
                self.progress = 0.0
                renpy.redraw(self, 0)
                if ev.type == pygame.KEYUP:
                    raise renpy.IgnoreEvent()

            if self.held and self.hold_start is not None:
                self.progress = min(1.0, (st - self.hold_start) / self.hold_time)
                if self.progress >= 1.0:
                    self.held = False
                    return True
                renpy.timeout(1.0 / 30.0)
            return None

        def render(self, width, height, st, at):
            r = renpy.Render(width, height)
            if self.held and self.hold_start is not None:
                self.progress = min(1.0, max(0.0, (st - self.hold_start) / self.hold_time))
                renpy.redraw(self, 0)
                renpy.timeout(1.0 / 30.0)
                alpha = 1.0
            elif st < 5.0:
                alpha = 0.9
                renpy.redraw(self, 5.0 - st)
            else:
                alpha = 0.6

            panel_w, panel_h = 304, 76
            x = max(0, int(width - panel_w - 60))
            y = max(0, int(height - panel_h - 55))
            def draw(child, px, py):
                rendered = renpy.render(Transform(child, alpha=alpha), width, height, st, at)
                r.blit(rendered, (px, py))

            draw(Solid("#100d10c9", xsize=panel_w, ysize=panel_h), x, y)
            draw(self.label, x + 16, y + 11)
            draw(self.caption, x + 16, y + 31)
            draw(Solid("#e9ddd244", xsize=panel_w - 32, ysize=2), x + 16, y + 65)
            fill_w = int((panel_w - 32) * self.progress)
            if fill_w > 0:
                draw(Solid("#dca78a", xsize=fill_w, ysize=2), x + 16, y + 65)
            return r

screen unlived_intro_video():
    modal True
    zorder 200

    add Solid("#000000")
    on "hide" action Stop("unlived_intro_audio", fadeout=0)
    add Movie(play=UNLIVED_INTRO_VIDEO, play_callback=unlived_play_intro, loop=False, size=(1920, 1080), xalign=0.5, yalign=0.5)
    add UnlivedHoldToSkip(UNLIVED_HOLD_TIME)

    timer UNLIVED_INTRO_LENGTH + 0.3 action Return(False)
    key "game_menu" action NullAction()

label unlived_intro:
    window hide
    $ quick_menu = False
    stop music fadeout 1.0
    scene black
    with Dissolve(0.5)
    call screen unlived_intro_loading with Dissolve(0.35)
    call screen unlived_intro_video with Dissolve(0.35)
    $ renpy.music.stop(channel="unlived_intro_audio", fadeout=0)
    $ quick_menu = True
    scene black
    with Dissolve(0.5)
    return
