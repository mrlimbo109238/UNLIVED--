## UNLIVED — living scenes: depth parallax for the menu art, light, dust, grain.
## The menu art was split into depth layers (room / boy and bed / foreground),
## each layer drifts against the pointer by its own amount.
init offset = 10

init python:
    import math

    def _u_clamp(v, lo, hi):
        return lo if v < lo else (hi if v > hi else v)

    class UnlivedParallax(renpy.Displayable, NoRollback):
        """
        layers: [(displayable, x, y, amp_x, amp_y), ...] in 1920x1080 space.
        Each layer is offset by -pointer * amp, with eased (critically damped) motion
        and a slow idle drift, so the room breathes even without a mouse.
        """

        def __init__(self, layers, size=(1920, 1080), tau=0.5, drift=1.0, **properties):
            super(UnlivedParallax, self).__init__(**properties)
            self.layers = [(renpy.displayable(d), float(x), float(y), float(ax), float(ay)) for (d, x, y, ax, ay) in layers]
            self.size = size
            self.tau = tau
            self.drift = drift
            self.cx = 0.0
            self.cy = 0.0
            self.last_st = None
            self.first_mouse = None
            self.live = False

        def render(self, width, height, st, at):
            w, h = self.size

            if self.last_st is None or st < self.last_st:
                dt = 0.0
            else:
                dt = min(st - self.last_st, 0.1)
            self.last_st = st

            enabled = persistent.unlived_parallax
            tx = ty = 0.0

            if enabled:
                mx, my = renpy.get_mouse_pos()
                if self.first_mouse is None:
                    self.first_mouse = (mx, my)
                elif not self.live and abs(mx - self.first_mouse[0]) + abs(my - self.first_mouse[1]) > 3:
                    self.live = True

                if self.live:
                    tx = _u_clamp((mx - w * 0.5) / (w * 0.5), -1.0, 1.0) * 0.84
                    ty = _u_clamp((my - h * 0.5) / (h * 0.5), -1.0, 1.0) * 0.84

                tx += self.drift * (0.13 * math.sin(st * 0.21) + 0.04 * math.sin(st * 0.57 + 1.3))
                ty += self.drift * (0.11 * math.sin(st * 0.16 + 0.7))

            if dt > 0:
                k = 1.0 - math.exp(-dt / self.tau)
                self.cx += (tx - self.cx) * k
                self.cy += (ty - self.cy) * k

            ox = -_u_clamp(self.cx, -1.0, 1.0)
            oy = -_u_clamp(self.cy, -1.0, 1.0)

            rv = renpy.Render(w, h)
            for d, x, y, ax, ay in self.layers:
                cr = renpy.render(d, w, h, st, at)
                rv.subpixel_blit(cr, (x + ox * ax, y + oy * ay))

            if enabled or abs(self.cx) > 0.0005 or abs(self.cy) > 0.0005:
                renpy.redraw(self, 0)

            return rv

        def visit(self):
            return [l[0] for l in self.layers]


    class UnlivedMotes(renpy.Displayable, NoRollback):
        """Floating motes (dust in the window light, out-of-focus bokeh)."""

        def __init__(self, image, count, area, zoom=(0.3, 0.8), alpha=(0.2, 0.6), speed=6.0,
                     wobble=(4.0, 14.0), seed=1, **properties):
            super(UnlivedMotes, self).__init__(**properties)
            import random as _random
            self.image = renpy.displayable(image)
            self.area = area
            rnd = _random.Random(seed)
            self.p = []
            for i in range(count):
                self.p.append((
                    rnd.uniform(0, 1), rnd.uniform(0, 1),                       # start
                    rnd.uniform(-1, 1) * speed, rnd.uniform(-1.0, 0.35) * speed,  # velocity (mostly rising)
                    rnd.uniform(*wobble), rnd.uniform(0.12, 0.45), rnd.uniform(0, 6.283),
                    rnd.uniform(*zoom), rnd.uniform(*alpha),
                    rnd.uniform(0.25, 0.9), rnd.uniform(0, 6.283),
                ))

        def render(self, width, height, st, at):
            ax, ay, aw, ah = self.area
            rv = renpy.Render(width, height)
            if not persistent.unlived_fx:
                return rv

            for (sx, sy, vx, vy, wob, wf, ph, z, a, tf, tp) in self.p:
                x = (sx * aw + vx * st) % aw
                y = (sy * ah + vy * st) % ah
                ex = min(x, aw - x) / (aw * 0.14)
                ey = min(y, ah - y) / (ah * 0.14)
                edge = _u_clamp(min(ex, ey), 0.0, 1.0)
                x += math.sin(st * wf + ph) * wob
                y += math.cos(st * wf * 0.8 + ph) * wob * 0.6
                tw = 0.6 + 0.4 * math.sin(st * tf * 2.0 + tp)
                alpha = a * tw * edge
                if alpha < 0.01:
                    continue
                t = Transform(self.image, alpha=alpha, zoom=z, blend="add")
                cr = renpy.render(t, width, height, st, at)
                cw, ch = cr.get_size()
                rv.subpixel_blit(cr, (ax + x - cw * 0.5, ay + y - ch * 0.5))

            renpy.redraw(self, 0)
            return rv

        def visit(self):
            return [self.image]

transform unlived_glow_pulse:
    blend "add"
    alpha 0.55
    block:
        easein 3.4 alpha 0.82
        ease 2.2 alpha 0.64
        ease 2.6 alpha 0.78
        easeout 3.8 alpha 0.5
        repeat

transform unlived_rays_pulse:
    blend "add"
    alpha 0.6
    block:
        ease 5.0 alpha 1.0
        ease 6.0 alpha 0.55
        repeat

image unlived_grain:
    Tile("images/ui/grain_0.png")
    pause 0.08
    Tile("images/ui/grain_1.png")
    pause 0.08
    Tile("images/ui/grain_2.png")
    pause 0.08
    Tile("images/ui/grain_3.png")
    pause 0.08
    repeat

image unlived_grain_fx = ConditionSwitch("persistent.unlived_fx", "unlived_grain", "True", Null())

## Main menu: the room, split into depth layers.
image unlived_menu_scene = UnlivedParallax([
    ("images/menu/parallax/room.jpg", 0, 0, 14, 7),
    (ConditionSwitch("persistent.unlived_fx", At("images/ui/glow_window.png", unlived_glow_pulse), "True", Null()), 940, -140, 14, 7),
    ("images/menu/parallax/figure.png", 0, 233, 36, 18),
    (ConditionSwitch("persistent.unlived_fx", At("images/ui/rays.png", unlived_rays_pulse), "True", Null()), 0, 0, 30, 15),
    (UnlivedMotes("images/ui/dust.png", 48, (620, 40, 1320, 940), zoom=(0.22, 0.75), alpha=(0.16, 0.5), speed=6.5, seed=4), 0, 0, 50, 25),
    ("images/menu/parallax/front.png", 1682, 758, 70, 35),
    (UnlivedMotes("images/ui/bokeh.png", 7, (-100, -100, 2120, 1280), zoom=(0.7, 1.6), alpha=(0.025, 0.07), speed=3.0, wobble=(10.0, 30.0), seed=11), 0, 0, 96, 48),
])

## Game menus: the same room, out of focus, with a gentle drift.
image unlived_menu_bg = UnlivedParallax([
    ("images/ui/menu_bg.jpg", 0, 0, 20, 11),
], tau=0.8, drift=0.8)

## In-game backdrop: quiet, static, no forced redraws while reading.
image unlived_ambient = Fixed(
    "images/ui/amb_base.jpg",
    Transform("images/ui/amb_warm.png", xpos=930, ypos=-430),
    Transform("images/ui/amb_cool.png", xpos=-560, ypos=170),
    "images/ui/vignette.png",
)

transform unlived_cam_full:
    subpixel True
    align (0.5, 0.5)
    zoom 1.16
    alpha 0.0
    parallel:
        easein 2.0 alpha 1.0
    parallel:
        easein_cubic 5.0 zoom 1.08

transform unlived_cam_return:
    subpixel True
    align (0.5, 0.5)
    zoom 1.09
    alpha 0.0
    parallel:
        easein 0.5 alpha 1.0
    parallel:
        easein_cubic 1.4 zoom 1.08

transform unlived_bg_cam:
    subpixel True
    align (0.5, 0.5)
    zoom 1.04
