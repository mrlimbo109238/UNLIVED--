# Story entry point is in scripts/story.rpy.
