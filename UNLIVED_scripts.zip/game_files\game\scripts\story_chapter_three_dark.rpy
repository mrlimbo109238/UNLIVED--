label chapter_three_dark:
    $ chapter_title = "Глава 3 / Мрак отчаяния"
    call chapter_card("Глава 3", "Мрак отчаяния")
    scene unlived_ch3_dark_01
    with Dissolve(0.35)
    narrator "Я сидел у окна психиатрического стационара, наблюдая за листьями, которым предстояло сыграть финальный аккорд своей жизни."
    narrator "Ведь мы с матерью оказались на грани. Как и почему — сейчас расскажу."
    narrator "Месяц после смерти брата"
    narrator "Я вернулся из школы и уже знал, какая картина меня ожидает."
    narrator "Мать каждый день искала утешение на дне бутылки. Отец пытался вытащить её, но и ему всё это надоело."
    narrator "Он почти не появлялся дома."
    scene unlived_ch3_dark_02
    with Dissolve(0.35)
    narrator "Не снимая обуви, я прошёл на кухню с надеждой хотя бы сегодня повлиять на матушку."
    narrator "Она сидела на полу. Вокруг были разбросаны бутылки и виднелись свежие лужи рвоты."
    narrator "Её мелко трясло. Руки то до боли сжимали волосы, то царапали лицо. Слипшиеся пряди свисали сосульками, закрывая его."
    voice "audio/voice/chapter3/ch3_dark_01_luka.ogg"
    luka "Мама, мне тоже его не хватает. Хотя бы нас не бросай."
    voice "audio/voice/chapter3/ch3_dark_02_nina.ogg"
    nina "Ах, тебе его не хватает? Может, тебе ещё и жаль? Это всё ты! Ты отнял у меня сына, ты отнял у меня будущее."
    narrator "Подняв голову, проговорила мать."
    voice "audio/voice/chapter3/ch3_dark_03_nina.ogg"
    nina "Если бы не твой папаша, я бы не стала тебя рожать! Говорила ему, что хватит и одного. Но нет, эта свинья начала визжать: «Раз так получилось, нельзя убивать ни в чём не повинное дитя!»"
    narrator "Её голос наполнился злобой и перешёл на крик."
    voice "audio/voice/chapter3/ch3_dark_04_nina.ogg"
    nina "Это ты должен был умереть, не он! Ты! Я ненавижу тебя! Лучше бы ты сдох!"
    narrator "Меня затрясло. Слёзы бессилия и отчаяния потекли неконтролируемо."
    thought_luka "«Я знаю. Я и сам себя ненавижу. Ты права, лучше бы умер я...»"
    menu:
        "Я не виноват в том, что случилось! И я тоже твой сын!":
            $ light_points += 1
            $ last_choice_light = True
            voice "audio/voice/chapter3/ch3_dark_05_luka.ogg"
            luka "Я не виноват в том, что случилось! И я тоже твой сын!"
        "Прости меня...":
            $ dark_points += 1
            $ last_choice_light = False
            voice "audio/voice/chapter3/ch3_dark_06_luka.ogg"
            luka "Прости меня..."
    narrator "Нина закричала и вцепилась мне в горло, сжимая пальцы до побеления."
    narrator "Из горла начали вырываться судорожные хрипы."
    narrator "Я видел её глаза, пропитанные ненавистью, но отчаянно пытался разглядеть хотя бы на дне хоть капельку тепла."
    narrator "Послышался звук ключей в двери. Игорь услышал нас и побежал на кухню."
    scene unlived_ch3_dark_03
    with Dissolve(0.35)
    narrator "Увиденное заставило его остолбенеть. Одним резким рывком он оттащил жену от меня и спрятал меня за спиной."
    voice "audio/voice/chapter3/ch3_dark_07_igor.ogg"
    igor "Беги в свою комнату. Нам с ней нужно поговорить."
    narrator "Прошептал отец."
    scene unlived_ch3_dark_04
    with Dissolve(0.35)
    narrator "Я побежал в свою комнату и запер дверь."
    voice "audio/voice/chapter3/ch3_dark_08_igor.ogg"
    igor "Нина, что ты творишь?! Ты хоть понимаешь, что натворила? Я устал это терпеть!"
    voice "audio/voice/chapter3/ch3_dark_09_nina.ogg"
    nina "О, смотрите, какой благородный праведник! Да если бы я когда-то не посмотрела в твою сторону, кому бы ты был нужен? Даже родная мать тебя бросила, как щенка сдала в приют! Ты жалкий и никчёмный кусок дерьма!"
    voice "audio/voice/chapter3/ch3_dark_10_igor.ogg"
    igor "Хочешь ты этого или нет, но тебе нужна помощь. Я сейчас же вызываю специалистов, и ты пройдёшь курс лечения."
    narrator "Мне было больно это слышать. Груз вины давил на грудь, а на горле всё ещё ощущалась хватка мамы."
    narrator "В голове раздался голос:"
    voice "audio/voice/chapter3/ch3_dark_inner_voice.ogg"
    inner_voice "Она права. Это ты-ы-ы долж-жен был умереть. Ты всегда был хуже него во вс-сём. Ты никогда не с-станешь хотя бы на грамм таким ж-же. Ты только вс-сё портиш-шь. Наберись с-смелос-сти и закончи это вс-сё..."
    narrator "Я открыл глаза и увидел у себя в руках канцелярский нож."
    narrator "Дальше всё было как в тумане. Я сделал глубокий надрез поперёк левого запястья. Удивился: боли не было."
    voice "audio/voice/chapter3/ch3_dark_11_igor.ogg"
    igor "Собери вещи, ты пока..."
    narrator "Отец оборвался на полуслове."
    scene unlived_ch3_dark_05
    with Dissolve(0.35)
    narrator "Он вошёл в комнату. В его глазах был животный страх."
    voice "audio/voice/chapter3/ch3_dark_12_igor.ogg"
    igor "Сынок, успокойся и положи нож. Мы всё исправим, всё будет хорошо..."
    narrator "Спокойно говоря, он стал потихоньку приближаться ко мне."
    narrator "Я посмотрел на отца и схватился за голову, сжимая виски."
    voice "audio/voice/chapter3/ch3_dark_13_luka.ogg"
    luka "Заставь его замолчать! Я больше не хочу это слышать!"
    narrator "Всхлипнув, я бросился в его объятия."
    scene unlived_ch3_dark_01
    with Dissolve(0.5)
    narrator "С того дня мы с мамой проходим лечение."
    scene unlived_ch3_dark_06
    with Dissolve(0.35)
    narrator "Отвернувшись от окна, я заметил рыжеволосую девочку."
    narrator "Она сидела возле кабинета психиатра и кого-то ждала. Захотелось подойти к ней. Но стоит ли?"
    menu:
        "Подойти и познакомиться.":
            $ nadya_route = True
            scene unlived_ch3_dark_07
            with Dissolve(0.35)
            narrator "Преодолев стеснение, я всё же решился."
            voice "audio/voice/chapter3/ch3_dark_14_luka.ogg"
            luka "Привет, меня зовут Лука. А тебя?"
            narrator "Я протянул ей руку. Она посмотрела на неё, и её пальцы слегка задрожали."
            voice "audio/voice/chapter3/ch3_dark_15_nadya.ogg"
            nadya "Надя. Приятно познакомиться."
            narrator "Сказала она, так и не пожав руку."
            voice "audio/voice/chapter3/ch3_dark_16_luka.ogg"
            luka "Не бойся, тут не так плохо, как кажется."
            narrator "Выпалил я."
            voice "audio/voice/chapter3/ch3_dark_17_nadya.ogg"
            nadya "Звучит очень утешительно."
            narrator "Саркастично сказала она."
            voice "audio/voice/chapter3/ch3_dark_18_nadya.ogg"
            nadya "Давно ты тут?"
            narrator "Её зелёные глаза смотрели на меня изучающе."
            voice "audio/voice/chapter3/ch3_dark_19_luka.ogg"
            luka "Нет..."
            narrator "Отчего-то мои щёки запылали. Это не укрылось от неё, и на губах появилась нежная улыбка."
            voice "audio/voice/chapter3/ch3_dark_20_nadya.ogg"
            nadya "Сколько тебе?"
            narrator "Заинтересованно спросила она."
            voice "audio/voice/chapter3/ch3_dark_21_luka.ogg"
            luka "Двенадцать, а тебе?"
            voice "audio/voice/chapter3/ch3_dark_22_nadya.ogg"
            nadya "Тринадцать."
            narrator "Теперь уже на её щеках появился румянец."
            voice "audio/voice/chapter3/ch3_dark_23_nadya.ogg"
            nadya "Почему ты здесь?"
            narrator "Необдуманно спросила она."
            voice "audio/voice/chapter3/ch3_dark_24_luka.ogg"
            luka "Я убил брата."
            narrator "На её лице мелькнул страх."
            voice "audio/voice/chapter3/ch3_dark_25_nadya.ogg"
            nadya "У... убил? Я думала, убийц отправляют в тюрьму."
            voice "audio/voice/chapter3/ch3_dark_26_luka.ogg"
            luka "Я тонул, а он бросился спасать. Ну и, в общем, выжил только я."
            narrator "Я опустил голову и боялся поднять её: боялся увидеть отвращение и осуждение."
            narrator "Она подалась вперёд, желая дотронуться до меня, но резко одёрнула руки."
            voice "audio/voice/chapter3/ch3_dark_27_nadya.ogg"
            nadya "Ты не виноват..."
            narrator "Послышался шёпот."
            voice "audio/voice/chapter3/ch3_dark_28_luka.ogg"
            luka "А ты почему?"
            narrator "Её глаза мгновенно потухли, лицо побледнело."
            voice "audio/voice/chapter3/ch3_dark_29_nadya.ogg"
            nadya "Я... я..."
            narrator "Попыталась выдавить хоть что-то она."
            narrator "В этот момент из кабинета вышла приятная на вид женщина и подошла к нам."
            voice "audio/voice/chapter3/ch3_dark_30_anna.ogg"
            anna "Наденька, пойдём домой. Врач сказал, что мы справимся без стационара."
            narrator "Посмотрев на мою новую знакомую, сказала она, затем перевела взгляд на меня."
            voice "audio/voice/chapter3/ch3_dark_31_anna.ogg"
            anna "Здравствуй, я Анна Павловна."
            narrator "Она улыбнулась, предлагая рукопожатие."
            narrator "Приняв его, я ответил:"
            voice "audio/voice/chapter3/ch3_dark_32_luka.ogg"
            luka "Лука. Очень приятно познакомиться."
            voice "audio/voice/chapter3/ch3_dark_33_anna.ogg"
            anna "Мне тоже. Жаль прерывать вашу беседу, но, боюсь, нам уже пора. Лисичка, я пока подожду тебя у входа."
            voice "audio/voice/chapter3/ch3_dark_34_luka.ogg"
            luka "У тебя очень добрая мама."
            narrator "Сказал я, как только Анна отошла."
            voice "audio/voice/chapter3/ch3_dark_35_nadya.ogg"
            nadya "Мне правда пора. Я очень рада знакомству. Хочешь, я ещё приду, но уже специально, чтобы тебя навестить?"
            narrator "Теребя пальцы, проговорила она."
            voice "audio/voice/chapter3/ch3_dark_36_luka.ogg"
            luka "Да, я был бы рад. Жаль, что телефоны запрещены, могли бы болтать когда захочется."
            voice "audio/voice/chapter3/ch3_dark_37_nadya.ogg"
            nadya "Согласна! Прости, думаю, мама уже заждалась. Я обязательно приду! До встречи!"
            narrator "Договорив, она вприпрыжку побежала к выходу."
            narrator "А я стоял и улыбался как идиот, глядя ей вслед."
            narrator "Моё пребывание в стационаре длилось ещё два месяца."
            narrator "Почти каждый день Надя навещала меня. Это скрашивало мои дни."
            narrator "Так я узнал, что они с мамой недавно переехали в наш город после развода родителей."
            narrator "Что её перевели в мою школу и мы будем учиться в одном классе."
            narrator "Но от чего она лечится, Надя так и не решалась рассказать."
            narrator "И всё же я заметил странность: она боялась мужчин и избегала их прикосновений."
        "Не беспокоить её.":
            $ nadya_route = False
            narrator "Всё же решив не беспокоить девочку, я ушёл к себе в палату."
            scene unlived_ch3_dark_01
            with Dissolve(0.35)
            narrator "Через два месяца меня выписали."
    scene unlived_ambient
    with Dissolve(0.7)
    jump route_selection

